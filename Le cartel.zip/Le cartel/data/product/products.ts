
import iphones from "@/data/product/iphone.json"
import samsung from "@/data/product/samsung.json"
import huawei from "@/data/product/huawei.json"
import macbook from "@/data/product/macbook.json"

export const PRODUCTS_PHARES = [
    "iphone-15-pro-max",
    "iphone-15",
    "iphone-14-pro-max",
    "iphone-14",
    "iphone-13-pro-max",
    "iphone-13",
    "iphone-12-pro-max",
    "iphone-12",
    "iphone-x",
];

export const PRODUCTS_PROMO = [
    "iphone-7",
    "iphone-6s",
    "iphone-6",
    "iphone-14",
    "iphone-se-2g",
    "iphone-13",
    "iphone-12-pro-max",
    "iphone-15",
    "iphone-x",
];

export const BEST_PRODUCTS = [
    "iphone-7s",
    "iphone-14",
    "iphone-14-pro-max",
    "iphone-13",
    "iphone-15-pro-max",
    "iphone-15",
    "iphone-12-mini",
    "iphone-11",
    "iphone-x",
];

export type DiscountType =  {
    is_discount: boolean,
    type?: "amount"|"percent",
    value?: number
}

export type ProductImageType = {
    src: string
    default: boolean
}
export type ProductVariationType = {
    price: number
    combinations: Array<string>
}

export type ProductType = {
    id: string,
    categoryId: number,
    name: string,
    description: string,
    price: number,
    discount?:DiscountType,
    details?: Record<string, Array<string>>,
    variations?: Array<ProductVariationType>,
    images?: Array<ProductImageType>
}

export const products:Array<ProductType> = [
    ...iphones,
    ...macbook,
    ...huawei,
    ...samsung
] as Array<ProductType>

export const getProductsPhares = () => {
    const productsPhares:Array<ProductType> = [];
    PRODUCTS_PHARES.forEach(ph => {
        const p = products.find(a => a.id == ph);
        if (p)
            productsPhares.push(p)
    });
    return productsPhares
}

export const getProductsPromo = () => {
    const productsPromo:Array<ProductType> = [];
    PRODUCTS_PROMO.forEach(ph => {
        const p = products.find(a => a.id == ph);
        if (p)
        productsPromo.push(p)
    });
    return productsPromo
}

export const getBestProducts = () => {
    const bestProducts:Array<ProductType> = [];
    BEST_PRODUCTS.forEach(ph => {
        const p = products.find(a => a.id == ph);
        if (p)
        bestProducts.push(p)
    });
    return bestProducts
}

export const getDiscountProducts = () => {
    return products.filter(p =>  p.discount && p.discount.is_discount)
}