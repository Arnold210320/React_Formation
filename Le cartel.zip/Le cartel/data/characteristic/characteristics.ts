
import colors from "@/data/characteristic/colors.json"
import capacities from "@/data/characteristic/capacity.json"
import states from "@/data/characteristic/states.json"
import sims from "@/data/characteristic/sims.json"

export type CharacteristicType = {
    id : string,
    name: string,
    value: string,
    group: number
}

export const characteristics:Array<CharacteristicType> = [
    ...capacities,
    ...states,
    ...colors,
    ...sims
]